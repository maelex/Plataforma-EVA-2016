<?php
sleep(5);
print_r($_FILES);
?> 